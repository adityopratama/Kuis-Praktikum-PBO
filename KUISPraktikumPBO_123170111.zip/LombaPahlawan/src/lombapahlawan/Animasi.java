/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */

public class Animasi extends Peserta {
    private double alurCerita;
    private double konten;
    private double kreativitas;
    private double sinematografi;

    public Animasi(String nama, String asalSekolah, double alurCerita, double konten, double kreativitas, double sinematografi) {
        super(nama, asalSekolah);
        this.alurCerita = alurCerita;
        this.konten = konten;
        this.kreativitas = kreativitas;
        this.sinematografi = sinematografi;
    }

    public double getNilaiAkhir() {
        return (alurCerita * 0.15) + (konten * 0.35) + (kreativitas * 0.35) + (sinematografi * 0.15);
    }

    public boolean isLolos() {
        return getNilaiAkhir() >= 85;
    }

    void setAlurCerita(double alurCerita) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setKonten(double konten) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setKreativitas(double kreativitas) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setSinematografi(double sinematografi) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */
import javax.swing.*;
import java.awt.event.*;

public class UbahNilai extends JFrame {
    private JTextField namaField, alurCeritaField, kontenField, kreativitasField, sinematografiField, strukturSuratField, isiSuratField, kaidahBahasaField;
    private JButton simpanButton;
    private JRadioButton animasiRadioButton, menulisSuratRadioButton;
    private ButtonGroup group;

    public UbahNilai() {
        setTitle("Ubah Nilai");

        JLabel namaLabel = new JLabel("Nama Tim/Peserta:");
        JLabel alurCeritaLabel = new JLabel("Nilai Alur Cerita:");
        JLabel kontenLabel = new JLabel("Nilai Konten:");
        JLabel kreativitasLabel = new JLabel("Nilai Kreativitas:");
        JLabel sinematografiLabel = new JLabel("Nilai Sinematografi:");
        JLabel strukturSuratLabel = new JLabel("Nilai Struktur Surat:");
        JLabel isiSuratLabel = new JLabel("Nilai Isi Surat:");
        JLabel kaidahBahasaLabel = new JLabel("Nilai Kaidah Bahasa:");

        namaField = new JTextField();
        alurCeritaField = new JTextField();
        kontenField = new JTextField();
        kreativitasField = new JTextField();
        sinematografiField = new JTextField();
        strukturSuratField = new JTextField();
        isiSuratField = new JTextField();
        kaidahBahasaField = new JTextField();

        simpanButton = new JButton("Simpan");

        animasiRadioButton = new JRadioButton("Animasi");
        menulisSuratRadioButton = new JRadioButton("Menulis Surat");

        group = new ButtonGroup();
        group.add(animasiRadioButton);
        group.add(menulisSuratRadioButton);

        setLayout(null);

        animasiRadioButton.setBounds(20, 20, 100, 20);
        menulisSuratRadioButton.setBounds(140, 20, 120, 20);

        namaLabel.setBounds(20, 50, 120, 20);
        namaField.setBounds(160, 50, 200, 20);

        alurCeritaLabel.setBounds(20, 80, 120, 20);
        alurCeritaField.setBounds(160, 80, 200, 20);
        kontenLabel.setBounds(20, 110, 120, 20);
        kontenField.setBounds(160, 110, 200, 20);
        kreativitasLabel.setBounds(20, 140, 120, 20);
        kreativitasField.setBounds(160, 140, 200, 20);
        sinematografiLabel.setBounds(20, 170, 120, 20);
        sinematografiField.setBounds(160, 170, 200, 20);

        strukturSuratLabel.setBounds(20, 200, 120, 20);
        strukturSuratField.setBounds(160, 200, 200, 20);
        isiSuratLabel.setBounds(20, 230, 120, 20);
        isiSuratField.setBounds(160, 230, 200, 20);
        kaidahBahasaLabel.setBounds(20, 260, 120, 20);
        kaidahBahasaField.setBounds(160, 260, 200, 20);

        simpanButton.setBounds(160, 300, 100, 30);

        add(animasiRadioButton);
        add(menulisSuratRadioButton);
        add(namaLabel);
        add(namaField);
        add(alurCeritaLabel);
        add(alurCeritaField);
        add(kontenLabel);
        add(kontenField);
        add(kreativitasLabel);
        add(kreativitasField);
        add(sinematografiLabel);
        add(sinematografiField);
        add(strukturSuratLabel);
        add(strukturSuratField);
        add(isiSuratLabel);
        add(isiSuratField);
        add(kaidahBahasaLabel);
        add(kaidahBahasaField);
        add(simpanButton);

        alurCeritaLabel.setVisible(false);
        alurCeritaField.setVisible(false);
        kontenLabel.setVisible(false);
        kontenField.setVisible(false);
        kreativitasLabel.setVisible(false);
        kreativitasField.setVisible(false);
        sinematografiLabel.setVisible(false);
        sinematografiField.setVisible(false);
        strukturSuratLabel.setVisible(false);
        strukturSuratField.setVisible(false);
        isiSuratLabel.setVisible(false);
        isiSuratField.setVisible(false);
        kaidahBahasaLabel.setVisible(false);
        kaidahBahasaField.setVisible(false);

        animasiRadioButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                alurCeritaLabel.setVisible(true);
                alurCeritaField.setVisible(true);
                kontenLabel.setVisible(true);
                kontenField.setVisible(true);
                kreativitasLabel.setVisible(true);
                kreativitasField.setVisible(true);
                sinematografiLabel.setVisible(true);
                sinematografiField.setVisible(true);
                strukturSuratLabel.setVisible(false);
                strukturSuratField.setVisible(false);
                isiSuratLabel.setVisible(false);
                isiSuratField.setVisible(false);
                kaidahBahasaLabel.setVisible(false);
                kaidahBahasaField.setVisible(false);
            }
        });

        menulisSuratRadioButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                alurCeritaLabel.setVisible(false);
                alurCeritaField.setVisible(false);
                kontenLabel.setVisible(false);
                kontenField.setVisible(false);
                kreativitasLabel.setVisible(false);
                kreativitasField.setVisible(false);
                sinematografiLabel.setVisible(false);
                sinematografiField.setVisible(false);
                strukturSuratLabel.setVisible(true);
                strukturSuratField.setVisible(true);
                isiSuratLabel.setVisible(true);
                isiSuratField.setVisible(true);
                kaidahBahasaLabel.setVisible(true);
                kaidahBahasaField.setVisible(true);
            }
        });

        simpanButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if (animasiRadioButton.isSelected()) {
                    String nama = namaField.getText();

                    for (Animasi peserta : Main.pesertaAnimasi) {
                        if (peserta.getNama().equalsIgnoreCase(nama)) {
                            double alurCerita = Double.parseDouble(alurCeritaField.getText());
                            double konten = Double.parseDouble(kontenField.getText());
                            double kreativitas = Double.parseDouble(kreativitasField.getText());
                            double sinematografi = Double.parseDouble(sinematografiField.getText());

                            peserta.setAlurCerita(alurCerita);
                            peserta.setKonten(konten);
                            peserta.setKreativitas(kreativitas);
                            peserta.setSinematografi(sinematografi);

                            JOptionPane.showMessageDialog(null, "Nilai peserta berhasil diubah.");
                            break;
                        }
                    }
                } else if (menulisSuratRadioButton.isSelected()) {
                    String nama = namaField.getText();

                    for (MenulisSurat peserta : Main.pesertaMenulisSurat) {
                        if (peserta.getNama().equalsIgnoreCase(nama)) {
                            double strukturSurat = Double.parseDouble(strukturSuratField.getText());
                            double isiSurat = Double.parseDouble(isiSuratField.getText());
                            double kreativitas = Double.parseDouble(kreativitasField.getText());
                            double kaidahBahasa = Double.parseDouble(kaidahBahasaField.getText());

                            peserta.setStrukturSurat(strukturSurat);
                            peserta.setIsiSurat(isiSurat);
                            peserta.setKreativitas(kreativitas);
                            peserta.setKaidahBahasa(kaidahBahasa);

                            JOptionPane.showMessageDialog(null, "Nilai peserta berhasil diubah.");
                            break;
                        }
                    }
                }
            }
        });
    }
}


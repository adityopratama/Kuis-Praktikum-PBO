/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;

public class TampilkanHasil extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JRadioButton animasiRadioButton, menulisSuratRadioButton;
    private ButtonGroup group;

    public TampilkanHasil() {
        setTitle("Tampilkan Hasil");

        animasiRadioButton = new JRadioButton("Animasi");
        menulisSuratRadioButton = new JRadioButton("Menulis Surat");

        group = new ButtonGroup();
        group.add(animasiRadioButton);
        group.add(menulisSuratRadioButton);

        animasiRadioButton.setBounds(20, 20, 100, 20);
        menulisSuratRadioButton.setBounds(140, 20, 120, 20);

        add(animasiRadioButton);
        add(menulisSuratRadioButton);

        model = new DefaultTableModel();
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 60, 460, 200);

        add(scrollPane);
        setLayout(null);

        animasiRadioButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                model.setRowCount(0);
                model.setColumnCount(0);
                model.addColumn("Nama Tim");
                model.addColumn("Asal Sekolah");
                model.addColumn("Nilai Akhir");
                model.addColumn("Lolos");

                for (Animasi peserta : Main.pesertaAnimasi) {
                    model.addRow(new Object[]{
                        peserta.getNama(),
                        peserta.getAsalSekolah(),
                        peserta.getNilaiAkhir(),
                        peserta.isLolos() ? "Ya" : "Tidak"
                    });
                }
            }
        });

        menulisSuratRadioButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                model.setRowCount(0);
                model.setColumnCount(0);
                model.addColumn("Nama Peserta");
                model.addColumn("Asal Sekolah");
                model.addColumn("Nilai Akhir");
                model.addColumn("Lolos");

                for (MenulisSurat peserta : Main.pesertaMenulisSurat) {
                    model.addRow(new Object[]{
                        peserta.getNama(),
                        peserta.getAsalSekolah(),
                        peserta.getNilaiAkhir(),
                        peserta.isLolos() ? "Ya" : "Tidak"
                    });
                }
            }
        });
    }
}


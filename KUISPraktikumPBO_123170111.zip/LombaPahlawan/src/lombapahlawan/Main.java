/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */

import java.util.ArrayList;
import javax.swing.JFrame;

public class Main {
    public static ArrayList<Animasi> pesertaAnimasi = new ArrayList<>();
    public static ArrayList<MenulisSurat> pesertaMenulisSurat = new ArrayList<>();

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MenuUtama frame = new MenuUtama();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setSize(400, 300);
                frame.setVisible(true);
            }
        });
    }
}


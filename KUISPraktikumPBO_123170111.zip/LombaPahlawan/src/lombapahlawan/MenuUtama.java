/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */

import javax.swing.*;
import java.awt.event.*;

public class MenuUtama extends JFrame {
    private JButton tambahPesertaButton, tampilkanHasilButton, ubahNilaiButton, hapusPesertaButton, keluarButton;

    public MenuUtama() {
        setTitle("Menu Utama");

        tambahPesertaButton = new JButton("Tambah Peserta");
        tampilkanHasilButton = new JButton("Tampilkan Hasil");
        ubahNilaiButton = new JButton("Ubah Nilai");
        hapusPesertaButton = new JButton("Hapus Peserta");
        keluarButton = new JButton("Keluar");

        setLayout(null);

        tambahPesertaButton.setBounds(100, 30, 200, 30);
        tampilkanHasilButton.setBounds(100, 70, 200, 30);
        ubahNilaiButton.setBounds(100, 110, 200, 30);
        hapusPesertaButton.setBounds(100, 150, 200, 30);
        keluarButton.setBounds(100, 190, 200, 30);

        add(tambahPesertaButton);
        add(tampilkanHasilButton);
        add(ubahNilaiButton);
        add(hapusPesertaButton);
        add(keluarButton);

        tambahPesertaButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new TambahPeserta().setVisible(true);
            }
        });

        tampilkanHasilButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new TampilkanHasil().setVisible(true);
            }
        });

        ubahNilaiButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new UbahNilai().setVisible(true);
            }
        });

        hapusPesertaButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                new HapusPeserta().setVisible(true);
            }
        });

        keluarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                System.exit(0);
            }
        });
    }
}


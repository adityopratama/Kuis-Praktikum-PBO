/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */
import javax.swing.*;
import java.awt.event.*;

public class HapusPeserta extends JFrame {
    private JTextField namaField;
    private JButton hapusButton;
    private JRadioButton animasiRadioButton, menulisSuratRadioButton;
    private ButtonGroup group;

    public HapusPeserta() {
        setTitle("Hapus Peserta");

        JLabel namaLabel = new JLabel("Nama Tim/Peserta:");

        namaField = new JTextField();

        hapusButton = new JButton("Hapus");

        animasiRadioButton = new JRadioButton("Animasi");
        menulisSuratRadioButton = new JRadioButton("Menulis Surat");

        group = new ButtonGroup();
        group.add(animasiRadioButton);
        group.add(menulisSuratRadioButton);

        setLayout(null);

        animasiRadioButton.setBounds(20, 20, 100, 20);
        menulisSuratRadioButton.setBounds(140, 20, 120, 20);

        namaLabel.setBounds(20, 50, 120, 20);
        namaField.setBounds(160, 50, 200, 20);

        hapusButton.setBounds(160, 80, 100, 30);

        add(animasiRadioButton);
        add(menulisSuratRadioButton);
        add(namaLabel);
        add(namaField);
        add(hapusButton);

        hapusButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                if (animasiRadioButton.isSelected()) {
                    String nama = namaField.getText();

                    for (int i = 0; i < Main.pesertaAnimasi.size(); i++) {
                        if (Main.pesertaAnimasi.get(i).getNama().equalsIgnoreCase(nama)) {
                            Main.pesertaAnimasi.remove(i);
                            JOptionPane.showMessageDialog(null, "Peserta berhasil dihapus.");
                            break;
                        }
                    }
                } else if (menulisSuratRadioButton.isSelected()) {
                    String nama = namaField.getText();

                    for (int i = 0; i < Main.pesertaMenulisSurat.size(); i++) {
                        if (Main.pesertaMenulisSurat.get(i).getNama().equalsIgnoreCase(nama)) {
                            Main.pesertaMenulisSurat.remove(i);
                            JOptionPane.showMessageDialog(null, "Peserta berhasil dihapus.");
                            break;
                        }
                    }
                }
            }
        });
    }
}


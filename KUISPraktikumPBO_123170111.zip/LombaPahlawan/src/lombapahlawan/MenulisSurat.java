/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */

public class MenulisSurat extends Peserta {
    private double strukturSurat;
    private double isiSurat;
    private double kreativitas;
    private double kaidahBahasa;

    public MenulisSurat(String nama, String asalSekolah, double strukturSurat, double isiSurat, double kreativitas, double kaidahBahasa) {
        super(nama, asalSekolah);
        this.strukturSurat = strukturSurat;
        this.isiSurat = isiSurat;
        this.kreativitas = kreativitas;
        this.kaidahBahasa = kaidahBahasa;
    }

    public double getNilaiAkhir() {
        return (strukturSurat * 0.10) + (isiSurat * 0.40) + (kreativitas * 0.30) + (kaidahBahasa * 0.20);
    }

    public boolean isLolos() {
        return getNilaiAkhir() >= 85;
    }

    void setStrukturSurat(double strukturSurat) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setIsiSurat(double iSurat) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setKreativitas(double kreativitas) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setKaidahBahasa(double kaidahBahasa) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}



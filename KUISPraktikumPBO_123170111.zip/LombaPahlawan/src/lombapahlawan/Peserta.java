/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lombapahlawan;

/**
 *
 * @author adity
 */

public class Peserta {
    protected String nama;
    protected String asalSekolah;

    public Peserta(String nama, String asalSekolah) {
        this.nama = nama;
        this.asalSekolah = asalSekolah;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getAsalSekolah() {
        return asalSekolah;
    }

    public void setAsalSekolah(String asalSekolah) {
        this.asalSekolah = asalSekolah;
    }
}


